const express = require('express');
const router = express.Router();
let students = require('../data/students');

// GET /students - Retrieve all students
router.get('/', (req, res) => {
  res.status(200).json(students);
});

// GET /students/:id - Retrieve a student by ID
router.get('/:id', (req, res) => {
  const studentId = parseInt(req.params.id, 10);
  const student = students.find(s => s.id === studentId);

  if (!student) {
    return res.status(404).json({ message: "Student not found" });
  }

  res.status(200).json(student);
});

// POST /students - Create a new student
router.post('/', (req, res) => {
  const { name, course } = req.body;

  if (!name || !course) {
    return res.status(400).json({ message: "Bad Request: 'name' and 'course' are required" });
  }

  const newStudent = {
    id: students.length ? students[students.length - 1].id + 1 : 1,
    name,
    course
  };

  students.push(newStudent);
  res.status(201).json(newStudent);
});

// PUT /students/:id - Update an existing student
router.put('/:id', (req, res) => {
  const studentId = parseInt(req.params.id, 10);
  const { name, course } = req.body;

  const student = students.find(s => s.id === studentId);

  if (!student) {
    return res.status(404).json({ message: "Student not found" });
  }

  if (!name || !course) {
    return res.status(400).json({ message: "Bad Request: 'name' and 'course' are required" });
  }

  student.name = name;
  student.course = course;

  res.status(200).json(student);
});

// DELETE /students/:id - Delete a student by ID
router.delete('/:id', (req, res) => {
  const studentId = parseInt(req.params.id, 10);
  const index = students.findIndex(s => s.id === studentId);

  if (index === -1) {
    return res.status(404).json({ message: "Student not found" });
  }

  const deletedStudent = students.splice(index, 1);
  res.status(200).json({ message: "Student deleted successfully", student: deletedStudent[0] });
});

module.exports = router;